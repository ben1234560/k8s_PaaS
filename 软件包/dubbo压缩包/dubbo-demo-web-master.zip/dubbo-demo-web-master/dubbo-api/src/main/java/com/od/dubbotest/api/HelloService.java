package com.od.dubbotest.api;


public interface HelloService {

	public String hello(String name);
}
